import csv

def get_data(filedata):
    with open ('/home/mad/TensorFlow/pusj/changes/LSTM-Time-Series-Analysis-using-Tensorflow/'+filedata, newline='') as csvfile:
        spamreader = csv.reader(csvfile, dialect='unix', delimiter=';', quotechar="|")
        i = 0
        j = []
        for row in spamreader:
#            print(row)
            if i >= 18:
                j = j + [row]
            else:
                i = i+1
    return j

