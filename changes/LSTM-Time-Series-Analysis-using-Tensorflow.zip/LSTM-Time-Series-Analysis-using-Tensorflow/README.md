# LSTM-Time-Series-Analysis-using-Tensorflow
LSTM Time Series Analysis using Tensorflow 1.0

Adapted from https://github.com/akash13singh/LSTM_TimeSeries


I got a good convergence with adding some noise (equal amount of distortion on all datasets (train, val and test)) and I got Tensorboard working today :-)

![alt text](https://github.com/pusj/LSTM-Time-Series-Analysis-using-Tensorflow/blob/master/graph-run%3D%20(2).png)

![alt text](https://github.com/pusj/LSTM-Time-Series-Analysis-using-Tensorflow/blob/master/noise_added.png)
